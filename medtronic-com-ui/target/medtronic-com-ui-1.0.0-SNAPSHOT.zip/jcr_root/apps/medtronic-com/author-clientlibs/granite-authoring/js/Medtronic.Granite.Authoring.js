Medtronic.Granite.Authoring = (function() {
   "use strict";
   // create the Medtronic namespace
   return {};
 })();