var Medtronic = Medtronic || {};
Medtronic.Granite = (function() {
   "use strict";
   // create the Medtronic.Granite namespace
   return {};
 })();