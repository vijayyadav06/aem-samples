var Medtronic = (function(Medtronic) {
  "use strict";
  // create the Medtronic namespace
  return Medtronic;
})(Medtronic || {});