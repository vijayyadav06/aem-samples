use([], function() {
  
  var src = properties.get("image", "");
  
  return {
    src: src
  };
});