use(["/apps/medtronic-com/components/common/SearchAuthoring.js"], function(searchAuthoring) {

  return searchAuthoring;
});