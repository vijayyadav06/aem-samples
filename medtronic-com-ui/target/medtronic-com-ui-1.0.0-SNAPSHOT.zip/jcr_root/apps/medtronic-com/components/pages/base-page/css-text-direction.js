use(["base-page.js"], function(basePage) {
  "use strict";

  return {
    "clientlibCategory": "medtronic-com." + basePage.textDirection
  };
});