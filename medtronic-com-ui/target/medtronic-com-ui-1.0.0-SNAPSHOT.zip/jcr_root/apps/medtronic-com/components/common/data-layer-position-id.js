use([], function() {
  return {
    ATTR_POSITION_ID: "medtronic-com.data-position-id"
  };
});