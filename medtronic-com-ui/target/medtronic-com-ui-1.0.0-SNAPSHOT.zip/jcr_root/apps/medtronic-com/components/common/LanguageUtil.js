use([], function() {
  var LanguageUtil = Packages.com.medtronic.com.util.LanguageUseUtil.getInstance(currentPage);
  
  return LanguageUtil;
});