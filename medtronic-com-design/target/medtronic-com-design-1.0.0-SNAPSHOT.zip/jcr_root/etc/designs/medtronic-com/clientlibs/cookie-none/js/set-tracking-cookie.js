(function() {
  setSatTrackCookie(true);
}());
