//TEMP ONLY 

$('.top-menu__btn').click(function() {
  $('.mega-menu').toggleClass('hide');
  $('.top-menu__btn > .icon-mdt-menu').toggleClass('icon-mdt-close');
});
